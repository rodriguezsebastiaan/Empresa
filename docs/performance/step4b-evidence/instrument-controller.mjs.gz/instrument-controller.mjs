import fs from 'node:fs';
const path='components/cinematic/use-cinematic-controller.ts';
const original=fs.readFileSync(path,'utf8');
fs.writeFileSync('.tmp-step4b-controller-original.txt',original);
let s=original.replace('    function render() {','    const probe = (label: string) => performance.mark(`step4b:${label}`)\n\n    function render() {\n      probe("render:start")');
const pairs=[
['      if (layoutDirty) measure()','      probe("geometry:start")\n      if (layoutDirty) measure()\n      probe("geometry:end")\n      probe("progress:start")'],
['      transitionDiagnostics?.sample(activeIndex, localProgress)','      probe("progress:end")\n      probe("prepare:start")\n      transitionDiagnostics?.sample(activeIndex, localProgress)'],
['      const introReveal =','      probe("prepare:end")\n      const introReveal ='],
['      root.style.setProperty(\n        \'--cinematic-global-progress\'','      probe("root-style:start")\n      root.style.setProperty(\n        \'--cinematic-global-progress\''],
['      setContentPresence(scrollY, introReveal)','      probe("root-style:end")\n      probe("content:start")\n      setContentPresence(scrollY, introReveal)\n      probe("content:end")'],
['      sourceSwitch.sync(new Map','      probe("source-sync:start")\n      sourceSwitch.sync(new Map'],
['      targets.forEach((target, index) => {','      probe("source-sync:end")\n      probe("scheduler:start")\n      targets.forEach((target, index) => {'],
['      const ready = new Set<number>()','      probe("scheduler:end")\n      probe("readiness:start")\n      const ready = new Set<number>()'],
['      const blend = getCinematicBlend({','      probe("readiness:end")\n      probe("blend:start")\n      const blend = getCinematicBlend({'],
['      const work = layerWriter.apply(blend.opacity, warm)','      probe("blend:end")\n      probe("layers:start")\n      const work = layerWriter.apply(blend.opacity, warm)\n      probe("layers:end")'],
['      scheduleIntroRebound()\n\n      const debug','      probe("rebound:start")\n      scheduleIntroRebound()\n      probe("rebound:end")\n      probe("render:end")\n\n      const debug']
];
for(const [a,b] of pairs){if(!s.includes(a))throw Error(a);s=s.replace(a,b)}
fs.writeFileSync(path,s);
