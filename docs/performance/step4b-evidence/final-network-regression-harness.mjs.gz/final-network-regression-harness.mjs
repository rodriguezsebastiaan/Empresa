import fs from 'node:fs/promises';
import {gzipSync} from 'node:zlib';
import {setTimeout as wait} from 'node:timers/promises';
const mode=process.argv[2]||'before';
await fs.mkdir('docs/performance/step4b-evidence',{recursive:true});
const init=`(()=>{
 const a=window.__audit={phase:'intro',marks:[],reads:[],loaf:[],long:[],raf:[],media:[],lcp:[],states:[],errors:[],heading:[]};
 let inside=false;
 const oldmark=performance.mark.bind(performance); performance.mark=function(n,o){if(n==='step4b:render:start')inside=true;const v=oldmark(n,o);if(n==='step4b:render:end')inside=false;return v};
 for(const key of ['innerHeight','innerWidth','scrollY']){const d=Object.getOwnPropertyDescriptor(window,key);if(d?.get&&d.configurable)Object.defineProperty(window,key,{...d,get(){const t=performance.now();const v=d.get.call(window);const dt=performance.now()-t;if(inside)a.reads.push({phase:a.phase,key,t,d:dt,stack:dt>1?new Error().stack:null});return v}})}
 const g=Element.prototype.getBoundingClientRect;Element.prototype.getBoundingClientRect=function(){const t=performance.now();const v=g.call(this);if(inside)a.reads.push({phase:a.phase,key:'rect',t,d:performance.now()-t});return v};
 for(const type of ['mark','long-animation-frame','longtask','largest-contentful-paint'])try{new PerformanceObserver(l=>{for(const e of l.getEntries()){
 if(type==='mark'&&e.name.startsWith('step4b:'))a.marks.push({phase:a.phase,name:e.name.slice(7),t:e.startTime});
 if(type==='long-animation-frame')a.loaf.push({phase:a.phase,t:e.startTime,d:e.duration,blocking:e.blockingDuration,scripts:e.scripts.map(s=>({name:s.sourceFunctionName,url:s.sourceURL,invoker:s.invoker,d:s.duration,forced:s.forcedStyleAndLayoutDuration}))});
 if(type==='longtask')a.long.push({phase:a.phase,t:e.startTime,d:e.duration});
 if(type==='largest-contentful-paint')a.lcp.push({t:e.startTime,renderTime:e.renderTime,text:e.element?.textContent?.slice(0,100),tag:e.element?.tagName});
 }}).observe({type,buffered:true})}catch{}
 let last;function tick(t){if(last)a.raf.push({phase:a.phase,t,d:t-last});last=t;requestAnimationFrame(tick)}requestAnimationFrame(tick);
 const seen=new WeakSet();let previous;const attach=()=>{const root=document.querySelector('.ks-cinematic-root');if(root&&root.dataset.introState!==previous){previous=root.dataset.introState;a.states.push({t:performance.now(),state:previous,scrollY:window.scrollY,video1:Array.from(document.querySelectorAll('video')).find(v=>v.dataset.cinematicVideo==='1')?.readyState})}
 document.querySelectorAll('video').forEach(v=>{if(seen.has(v))return;seen.add(v);for(const type of ['loadedmetadata','loadeddata','playing','waiting','stalled','ended','error','canplay'])v.addEventListener(type,()=>a.media.push({t:performance.now(),index:v.dataset.cinematicVideo??'internal',type,time:v.currentTime,ready:v.readyState,src:v.getAttribute('src')}));if(v.requestVideoFrameCallback){let first=true;const frame=(t,m)=>{if(first){a.media.push({t,index:v.dataset.cinematicVideo??'internal',type:'first-frame',mediaTime:m.mediaTime,opacity:v.style.opacity,visibility:v.style.visibility,ready:v.readyState});first=false}if(v.dataset.cinematicVideo==='0'){if(v.readyState>=2&&Number(v.style.opacity)>0&&v.style.visibility!=='hidden')a.media.push({t,index:'0',type:'first-usable-frame',mediaTime:m.mediaTime,opacity:v.style.opacity,visibility:v.style.visibility,ready:v.readyState});else v.requestVideoFrameCallback(frame)}};v.requestVideoFrameCallback(frame)}});
 if(!a.inserted&&document.querySelector('#hero h1 span'))a.inserted=performance.now();};new MutationObserver(attach).observe(document,{subtree:true,childList:true,attributes:true,attributeFilter:['data-intro-state','src']});document.addEventListener('DOMContentLoaded',attach);
 window.addEventListener('error',e=>a.errors.push(e.message));
 })()`;
async function session(width,height,network=false){
 const target=await fetch('http://127.0.0.1:9222/json/new?about:blank',{method:'PUT'}).then(r=>r.json());
 const ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise(r=>ws.onopen=r);let id=0;const pending=new Map(),events=[];let trace=[];let tracedone;
 ws.onmessage=e=>{const v=JSON.parse(e.data);if(v.id){const p=pending.get(v.id);pending.delete(v.id);v.error?p?.reject(Error(JSON.stringify(v.error))):p?.resolve(v.result)}else{if(v.method==='Tracing.dataCollected')trace.push(...v.params.value);else if(v.method==='Tracing.tracingComplete')tracedone?.();else events.push(v)}};
 const call=(method,params={})=>new Promise((resolve,reject)=>{const i=++id;pending.set(i,{resolve,reject});ws.send(JSON.stringify({id:i,method,params}))});
 const evaluate=async expression=>(await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true})).result?.value;
 await call('Page.enable');await call('Runtime.enable');await call('Network.enable');await call('Network.setCacheDisabled',{cacheDisabled:true});await call('Network.clearBrowserCache');
 await call('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:width<767});await call('Page.addScriptToEvaluateOnNewDocument',{source:init});
 if(network)await call('Network.emulateNetworkConditions',{offline:false,latency:80,downloadThroughput:1125000,uploadThroughput:187500,connectionType:'cellular4g'});
 return {call,evaluate,events,async startTrace(){await call('Tracing.start',{categories:'devtools.timeline,blink.user_timing,disabled-by-default-devtools.timeline.stack',options:'record-as-much-as-possible'})},async saveTrace(name){await call('Tracing.end');await new Promise(r=>tracedone=r);await fs.writeFile('docs/performance/step4b-evidence/'+name+'.trace.json.gz',gzipSync(JSON.stringify({traceEvents:trace})));trace=[]},async close(){await call('Page.close');ws.close()}};
}
const results=[];
async function snapshot(s){return await s.evaluate(`(()=>{const a=__audit;return {...a,paint:performance.getEntriesByType('paint').map(e=>({name:e.name,t:e.startTime})),resources:performance.getEntriesByType('resource').map(e=>({url:e.name,t:e.startTime,end:e.responseEnd,transfer:e.transferSize,encoded:e.encodedBodySize})),scrollY,rootState:document.querySelector('.ks-cinematic-root')?.dataset.introState,videos:[...document.querySelectorAll('video')].map(v=>({index:v.dataset.cinematicVideo,src:v.getAttribute('src'),ready:v.readyState,time:v.currentTime,opacity:v.style.opacity,visibility:v.style.visibility,paused:v.paused,error:v.error?.code})),holds:document.querySelectorAll('[data-cinematic-source-hold]').length,diagnostics:document.querySelectorAll('[data-cinematic-seek],[data-cinematic-transitions],[data-cinematic-source-switch],.ks-cinematic-debug').length}})()`)}
async function wheel(s,w,h,delta){await s.call('Input.dispatchMouseEvent',{type:'mouseWheel',x:w/2,y:h*.75,deltaY:delta,deltaX:0})}
if(mode==='before'||mode==='after')for(const [profile,w,h] of [['desktop',1440,900],['mobile',390,844]])for(let run=1;run<=3;run++){
 const s=await session(w,h);if(run===1)await s.startTrace();await s.call('Page.navigate',{url:'http://127.0.0.1:4173/'});await wait(7600);
 await s.evaluate(`__audit.phase='boundaries'`);
 const bounds=await s.evaluate(`['projects','solutions','contact'].map(id=>document.getElementById(id).getBoundingClientRect().top+scrollY)`);
 for(const y of bounds){await s.evaluate(`scrollTo(0,${y-12})`);await wait(220);for(let j=0;j<3;j++){await wheel(s,w,h,24);await wait(100);await wheel(s,w,h,-24);await wait(100)}}
 await wait(250);const a=await snapshot(s);a.profile=profile;a.run=run;results.push(a);if(run===1)await s.saveTrace(mode+'-'+profile);await s.close();console.log(mode,profile,run,'loaf',a.loaf.length,'maxRead',Math.max(0,...a.reads.map(r=>r.d)));
}
if(mode==='network'||mode==='network-repeat'||mode==='network-isolation')for(const [profile,w,h] of [['desktop',1440,900],['mobile',390,844]]){
 if(['network-isolation','network-repeat'].includes(mode)&&profile==='mobile')continue;
 const s=await session(w,h,true);if(mode==='network-isolation')await s.call('Network.setBlockedURLs',{urls:['*video1_SistemaSolar_h264.mp4*']});await s.call('Page.navigate',{url:'http://127.0.0.1:4173/'});
 // Heading observations are separated from controller timing trials because computed-style/rect reads can affect layout.
 for(let i=0;i<100;i++){await wait(200);await s.evaluate(`(()=>{const h=document.querySelector('#hero h1 span'),c=document.querySelector('#hero > .ks-scene-content'),r=document.querySelector('.ks-cinematic-root'),v=document.querySelector('[data-cinematic-video="0"]');if(h&&c){const box=h.getBoundingClientRect();__audit.heading.push({t:performance.now(),top:box.top,bottom:box.bottom,opacity:getComputedStyle(h).opacity,parentOpacity:getComputedStyle(c).opacity,reveal:r.style.getPropertyValue('--cinematic-intro-reveal'),videoTime:v.currentTime,state:r.dataset.introState,video1:document.querySelector('[data-cinematic-video="1"]').readyState});}})()`)}
 const a=await snapshot(s);a.profile=profile;a.network={latency:80,downloadBytesPerSecond:1125000,uploadBytesPerSecond:187500};a.networkRequests=s.events.filter(e=>e.method.startsWith('Network.'));results.push(a);await s.close();console.log('network',profile,'state',a.rootState,'media',a.media.filter(e=>e.index==='0'));
}
if(mode==='regression'){
 for(const [profile,w,h] of [['desktop',1440,900],['mobile',390,844]]){
 const s=await session(w,h);await s.call('Page.navigate',{url:'http://127.0.0.1:4173/'});await wait(7600);const checks={profile,automatic:await snapshot(s),samples:[]};
 const max=await s.evaluate('document.documentElement.scrollHeight-innerHeight');let n=Math.ceil(max/(h*.8))+3;
 for(const [phase,d] of [['forward',h*.8],['reverse',-h*.8]]){await s.evaluate(`__audit.phase='${phase}'`);for(let j=0;j<n;j++){await wheel(s,w,h,d);await wait(130);checks.samples.push({phase,...await s.evaluate(`({scrollY,videos:[...document.querySelectorAll('video')].filter(v=>Number(v.style.opacity)>0&&v.style.visibility!=='hidden').map(v=>({index:v.dataset.cinematicVideo,ready:v.readyState,time:v.currentTime,opacity:v.style.opacity}))})`)})}await wait(1000);checks[phase]=await snapshot(s);const shot=await s.call('Page.captureScreenshot',{format:'jpeg',quality:65});await fs.writeFile('docs/performance/step4b-evidence/'+profile+'-'+phase+'.jpg',Buffer.from(shot.data,'base64'))}
 await s.evaluate('scrollTo(0,innerHeight*2.5)');await wait(500);
 for(const [sw,sh] of [[w<767?1440:390,w<767?900:844],[w,h]]){await s.call('Emulation.setDeviceMetricsOverride',{width:sw,height:sh,deviceScaleFactor:1,mobile:sw<767});await wait(80);const shot=await s.call('Page.captureScreenshot',{format:'jpeg',quality:65});await fs.writeFile('docs/performance/step4b-evidence/'+profile+'-swap-'+sw+'.jpg',Buffer.from(shot.data,'base64'));(checks.swaps??=[]).push({early:await snapshot(s)});await wait(1500);checks.swaps.at(-1).settled=await snapshot(s)}
 await s.call('Page.navigate',{url:'http://127.0.0.1:4173/'});await wait(1000);await wheel(s,w,h,100);await wait(600);checks.interruption=await snapshot(s);
 for(const url of ['/nosotros','/soluciones']){await s.call('Page.navigate',{url:'http://127.0.0.1:4173'+url});await wait(1600);await wheel(s,w,h,h);await wait(300);(checks.internal??=[]).push({url,...await snapshot(s)})}
 checks.exceptions=s.events.filter(e=>e.method==='Runtime.exceptionThrown'||(e.method==='Runtime.consoleAPICalled'&&e.params.type==='error'));results.push(checks);await s.close();console.log('regression',profile,'complete');
 }
}
await fs.writeFile('docs/performance/step4b-evidence/'+mode+'.json',JSON.stringify(results,null,2));
