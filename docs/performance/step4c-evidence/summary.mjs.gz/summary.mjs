import fs from 'node:fs';
const dir='docs/performance/step4c-evidence/';let result=[];
for(const mode of ['baseline','lead15','lead25','lead25-repeat','fast','mobile'])if(fs.existsSync(dir+mode+'.json'))for(const r of JSON.parse(fs.readFileSync(dir+mode+'.json'))){
 const v0=r.media.filter(e=>e.index==='0'),v1=r.media.filter(e=>e.index==='1');const first=type=>v0.find(e=>e.type===type)?.t;
 const observationEnd=Math.max(...r.heading.map(e=>e.t));
 const stalls=v0.filter(e=>e.type==='waiting'&&e.time>.01).map(e=>({at:e.t,mediaTime:e.time,end:v0.find(n=>n.type==='playing'&&n.t>e.t)?.t})).map(e=>({...e,censored:e.end===undefined,d:(e.end??observationEnd)-e.at}));const handoff=r.states.find(e=>e.state==='complete');
 const requests=new Map(r.networkRequests.filter(e=>e.method==='Network.requestWillBeSent').map(e=>[e.params.requestId,e.params.request.url]));const nav=r.networkRequests.find(e=>e.method==='Network.requestWillBeSent'&&e.params.type==='Document')?.params.timestamp;const bytes={};
 for(const e of r.networkRequests.filter(e=>e.method==='Network.dataReceived'&&e.params.timestamp<=nav+(handoff?.t??14000)/1000)){const url=requests.get(e.params.requestId);if(url?.includes('/videos/'))(bytes[url]??=0,bytes[url]+=e.params.dataLength)}
 const r1=r.networkRequests.find(e=>e.method==='Network.requestWillBeSent'&&e.params.request.url.includes('video1_'));
 const promotion=r1?(r1.params.timestamp-nav)*1000:null;const at=v0.filter(e=>e.t<=promotion&&e.buffered?.length).at(-1);
 result.push({mode,profile:r.profile,run:r.run,fcp:r.paint.find(e=>e.name==='first-contentful-paint')?.t,firstUsable:first('first-usable-frame'),playing:first('playing'),stallCount:stalls.length,stallMs:stalls.reduce((s,e)=>s+e.d,0),longestStall:Math.max(0,...stalls.map(e=>e.d)),stalls,video1Loaded:v1.find(e=>e.type==='loadeddata')?.t,promotion,bufferAtPromotion:at,handoff,heroVisible:r.heroVisible,bytes,errors:r.errors,state:r.rootState,videos:r.videos});
}
fs.writeFileSync(dir+'summary.json',JSON.stringify(result,null,2));for(const r of result)console.log(r.mode,r.run,'usable',r.firstUsable?.toFixed(1),'playing',r.playing?.toFixed(1),'stalls',r.stallCount,r.stallMs.toFixed(1),'v1',r.video1Loaded?.toFixed(1),'promotion',r.promotion?.toFixed(1),'handoff',r.handoff?.video1,r.handoff?.t.toFixed(1),'visible',r.heroVisible?.t);
