type StartupOptions = {
  enabled: boolean
  prepareHero: () => void
}

// Desktop native-intro startup only: protect video0's initial bandwidth, then
// release video1 to the existing preparation/readiness system. Not scene preload.
export function createCinematicStartupBuffering(video: HTMLVideoElement, options: StartupOptions) {
  const bufferLeadSeconds = 2.5
  const deadlineMs = 5000
  let deferred = options.enabled
  let deadline: number | null = null
  const events = ['loadeddata', 'playing', 'progress', 'canplay', 'timeupdate'] as const

  const cleanup = () => {
    if (deadline !== null) window.clearTimeout(deadline)
    deadline = null
    events.forEach(event => video.removeEventListener(event, checkBuffer))
    video.removeEventListener('error', promote)
  }
  function promote() {
    if (!deferred) return
    deferred = false
    cleanup()
    options.prepareHero()
  }
  function checkBuffer() {
    if (!deferred || video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA || video.paused) return
    // TimeRanges is a media snapshot, not a DOM layout read. Use only the
    // contiguous range containing the current playback position, never a gap.
    const position = video.currentTime
    const buffered = video.buffered
    const requiredLead = Number.isFinite(video.duration)
      ? Math.min(bufferLeadSeconds, Math.max(0, video.duration - position))
      : bufferLeadSeconds
    for (let index = 0; index < buffered.length; index++) {
      if (buffered.start(index) <= position && buffered.end(index) >= position &&
        buffered.end(index) - position >= requiredLead) {
        promote()
        return
      }
    }
  }
  if (deferred) {
    events.forEach(event => video.addEventListener(event, checkBuffer))
    video.addEventListener('error', promote)
    // One absolute budget, armed before the native play request. Starting earlier
    // than loadeddata also bounds media that never reaches that startup event.
    deadline = window.setTimeout(promote, deadlineMs)
  }
  return {
    isDeferring: () => deferred,
    promote,
    dispose() {
      deferred = false
      cleanup()
    },
  }
}
