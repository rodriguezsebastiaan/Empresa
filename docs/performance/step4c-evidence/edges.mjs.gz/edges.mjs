import fs from 'node:fs/promises';
import {gzipSync} from 'node:zlib';
import {setTimeout as wait} from 'node:timers/promises';
const mode=process.argv[2]||'before';
await fs.mkdir('docs/performance/step4b-evidence',{recursive:true});
const init=`(()=>{
 const a=window.__audit={phase:'intro',marks:[],reads:[],loaf:[],long:[],raf:[],media:[],lcp:[],states:[],errors:[],heading:[]};
 let inside=false;
 const oldmark=performance.mark.bind(performance); performance.mark=function(n,o){if(n==='step4b:render:start')inside=true;const v=oldmark(n,o);if(n==='step4b:render:end')inside=false;return v};
 for(const key of ['innerHeight','innerWidth','scrollY']){const d=Object.getOwnPropertyDescriptor(window,key);if(d?.get&&d.configurable)Object.defineProperty(window,key,{...d,get(){const t=performance.now();const v=d.get.call(window);const dt=performance.now()-t;if(inside)a.reads.push({phase:a.phase,key,t,d:dt,stack:dt>1?new Error().stack:null});return v}})}
 const g=Element.prototype.getBoundingClientRect;Element.prototype.getBoundingClientRect=function(){const t=performance.now();const v=g.call(this);if(inside)a.reads.push({phase:a.phase,key:'rect',t,d:performance.now()-t});return v};
 for(const type of ['mark','long-animation-frame','longtask','largest-contentful-paint'])try{new PerformanceObserver(l=>{for(const e of l.getEntries()){
 if(type==='mark'&&e.name.startsWith('step4b:'))a.marks.push({phase:a.phase,name:e.name.slice(7),t:e.startTime});
 if(type==='long-animation-frame')a.loaf.push({phase:a.phase,t:e.startTime,d:e.duration,blocking:e.blockingDuration,scripts:e.scripts.map(s=>({name:s.sourceFunctionName,url:s.sourceURL,invoker:s.invoker,d:s.duration,forced:s.forcedStyleAndLayoutDuration}))});
 if(type==='longtask')a.long.push({phase:a.phase,t:e.startTime,d:e.duration});
 if(type==='largest-contentful-paint')a.lcp.push({t:e.startTime,renderTime:e.renderTime,text:e.element?.textContent?.slice(0,100),tag:e.element?.tagName});
 }}).observe({type,buffered:true})}catch{}
 let last;function tick(t){const v1=document.querySelector('[data-cinematic-video="1"]');if(v1&&!a.heroVisible&&Number(v1.style.opacity)>0&&v1.style.visibility==='visible')a.heroVisible={t,ready:v1.readyState,time:v1.currentTime};if(last)a.raf.push({phase:a.phase,t,d:t-last});last=t;requestAnimationFrame(tick)}requestAnimationFrame(tick);
 const seen=new WeakSet();let previous;const attach=()=>{const root=document.querySelector('.ks-cinematic-root');if(root&&root.dataset.introState!==previous){previous=root.dataset.introState;a.states.push({t:performance.now(),state:previous,scrollY:window.scrollY,video1:Array.from(document.querySelectorAll('video')).find(v=>v.dataset.cinematicVideo==='1')?.readyState})}
 document.querySelectorAll('video').forEach(v=>{if(seen.has(v))return;seen.add(v);for(const type of ['loadedmetadata','loadeddata','playing','waiting','stalled','ended','error','canplay','progress','suspend','timeupdate'])v.addEventListener(type,()=>a.media.push({t:performance.now(),index:v.dataset.cinematicVideo??'internal',type,time:v.currentTime,ready:v.readyState,src:v.getAttribute('src'),paused:v.paused,buffered:[...Array(v.buffered.length)].map((_,i)=>[v.buffered.start(i),v.buffered.end(i)])}));if(v.requestVideoFrameCallback){let first=true;const frame=(t,m)=>{if(first){a.media.push({t,index:v.dataset.cinematicVideo??'internal',type:'first-frame',mediaTime:m.mediaTime,opacity:v.style.opacity,visibility:v.style.visibility,ready:v.readyState});first=false}if(v.dataset.cinematicVideo==='0'){if(v.readyState>=2&&Number(v.style.opacity)>0&&v.style.visibility!=='hidden')a.media.push({t,index:'0',type:'first-usable-frame',mediaTime:m.mediaTime,opacity:v.style.opacity,visibility:v.style.visibility,ready:v.readyState});else v.requestVideoFrameCallback(frame)}};v.requestVideoFrameCallback(frame)}});
 if(!a.inserted&&document.querySelector('#hero h1 span'))a.inserted=performance.now();};new MutationObserver(attach).observe(document,{subtree:true,childList:true,attributes:true,attributeFilter:['data-intro-state','src']});document.addEventListener('DOMContentLoaded',attach);
 window.addEventListener('error',e=>a.errors.push(e.message));
 })()`;
async function session(width,height,network=false){
 const target=await fetch('http://127.0.0.1:9222/json/new?about:blank',{method:'PUT'}).then(r=>r.json());
 const ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise(r=>ws.onopen=r);let id=0;const pending=new Map(),events=[];let trace=[];let tracedone;
 ws.onmessage=e=>{const v=JSON.parse(e.data);if(v.id){const p=pending.get(v.id);pending.delete(v.id);v.error?p?.reject(Error(JSON.stringify(v.error))):p?.resolve(v.result)}else{if(v.method==='Tracing.dataCollected')trace.push(...v.params.value);else if(v.method==='Tracing.tracingComplete')tracedone?.();else events.push(v)}};
 const call=(method,params={})=>new Promise((resolve,reject)=>{const i=++id;pending.set(i,{resolve,reject});ws.send(JSON.stringify({id:i,method,params}))});
 const evaluate=async expression=>(await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true})).result?.value;
 await call('Page.enable');await call('Runtime.enable');await call('Network.enable');await call('Network.setCacheDisabled',{cacheDisabled:true});await call('Network.clearBrowserCache');
 await call('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:width<767});await call('Page.addScriptToEvaluateOnNewDocument',{source:init});
 if(network)await call('Network.emulateNetworkConditions',{offline:false,latency:80,downloadThroughput:1125000,uploadThroughput:187500,connectionType:'cellular4g'});
 return {call,evaluate,events,async startTrace(){await call('Tracing.start',{categories:'devtools.timeline,blink.user_timing,disabled-by-default-devtools.timeline.stack',options:'record-as-much-as-possible'})},async saveTrace(name){await call('Tracing.end');await new Promise(r=>tracedone=r);await fs.writeFile('docs/performance/step4c-evidence/'+name+'.trace.json.gz',gzipSync(JSON.stringify({traceEvents:trace})));trace=[]},async close(){await call('Page.close');ws.close()}};
}
const results=[];
async function snapshot(s){return await s.evaluate(`(()=>{const a=__audit;return {...a,paint:performance.getEntriesByType('paint').map(e=>({name:e.name,t:e.startTime})),resources:performance.getEntriesByType('resource').map(e=>({url:e.name,t:e.startTime,end:e.responseEnd,transfer:e.transferSize,encoded:e.encodedBodySize})),scrollY,rootState:document.querySelector('.ks-cinematic-root')?.dataset.introState,videos:[...document.querySelectorAll('video')].map(v=>({index:v.dataset.cinematicVideo,src:v.getAttribute('src'),ready:v.readyState,time:v.currentTime,opacity:v.style.opacity,visibility:v.style.visibility,paused:v.paused,error:v.error?.code})),holds:document.querySelectorAll('[data-cinematic-source-hold]').length,diagnostics:document.querySelectorAll('[data-cinematic-seek],[data-cinematic-transitions],[data-cinematic-source-switch],.ks-cinematic-debug').length}})()`)}
async function wheel(s,w,h,delta){await s.call('Input.dispatchMouseEvent',{type:'mouseWheel',x:w/2,y:h*.75,deltaY:delta,deltaX:0})}

const edgeResults=[];
for(const name of ['interruption','desktop-mobile','mobile-desktop','reduced','hash']){
 const mobile=name==='mobile-desktop';const s=await session(mobile?390:1440,mobile?844:900,!['reduced','hash','mobile-desktop'].includes(name));
 if(name==='reduced')await s.call('Emulation.setEmulatedMedia',{features:[{name:'prefers-reduced-motion',value:'reduce'}]});
 await s.call('Page.navigate',{url:'http://127.0.0.1:4173/'+(name==='hash'?'#hero':'')});
 let before;
 for(let i=0;i<50;i++){await wait(75);before=await s.evaluate("(()=>{const r=document.querySelector('.ks-cinematic-root'),v=[...document.querySelectorAll('video')];return {state:r?.dataset.introState,videos:v.map(x=>({src:x.getAttribute('src'),prepared:x.dataset.prepared,ready:x.readyState,time:x.currentTime,paused:x.paused})),at:performance.now()}})()");if(before?.state==='running'||before?.state==='skipped')break}
 // Final fallback has the original eager video1; record the original behavior.
 if(name==='interruption')await wheel(s,1440,900,900);
 if(name==='desktop-mobile')await s.call('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});
 if(name==='mobile-desktop')await s.call('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false});
 await wait(150);const immediate=await snapshot(s);await wait(5400);const afterDeadline=await snapshot(s);await wait(3000);const settled=await snapshot(s);
 const row={name,before,immediate,afterDeadline,settled,exceptions:s.events.filter(e=>e.method==='Runtime.exceptionThrown'||(e.method==='Runtime.consoleAPICalled'&&e.params.type==='error'))};
 edgeResults.push(row);await s.close();console.log(name,before.state,'beforeHero',before.videos[1].src,'immediate',immediate.rootState,immediate.videos[1]?.src,'settled',settled.rootState,settled.videos[1]?.src);
 await fs.writeFile('docs/performance/step4c-evidence/edges.json',JSON.stringify(edgeResults,null,2));
}
