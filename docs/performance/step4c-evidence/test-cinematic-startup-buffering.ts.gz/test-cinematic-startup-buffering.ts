import assert from 'node:assert/strict'
import { createCinematicStartupBuffering } from '../components/cinematic/cinematic-startup-buffering'

const timers = new Map<number, { callback: () => void; delay: number }>()
let nextId = 0
Object.assign(globalThis, {
  HTMLMediaElement: { HAVE_CURRENT_DATA: 2 },
  window: {
    setTimeout(callback: () => void, delay: number) { timers.set(++nextId, { callback, delay }); return nextId },
    clearTimeout(id: number) { timers.delete(id) },
  },
})
class Video extends EventTarget {
  readyState = 4
  paused = false
  currentTime = 1
  duration = 6
  ranges = [[0, 2]]
  listeners = new Set<string>()
  get buffered() {
    const ranges = this.ranges.map(range => [...range])
    return { length: ranges.length, start: (i: number) => ranges[i][0], end: (i: number) => ranges[i][1] }
  }
  override addEventListener(type: string, listener: EventListenerOrEventListenerObject | null) {
    this.listeners.add(type); super.addEventListener(type, listener)
  }
  override removeEventListener(type: string, listener: EventListenerOrEventListenerObject | null) {
    this.listeners.delete(type); super.removeEventListener(type, listener)
  }
}
const fixture = (enabled = true) => {
  const video = new Video()
  let preparations = 0
  const policy = createCinematicStartupBuffering(video as unknown as HTMLVideoElement,
    { enabled, prepareHero: () => preparations++ })
  return { video, policy, preparations: () => preparations }
}
const a = fixture()
assert.equal(a.policy.isDeferring(), true)
assert.equal(timers.size, 1)
assert.equal([...timers.values()][0].delay, 5000)
a.video.dispatchEvent(new Event('playing'))
assert.equal(a.preparations(), 0)
a.video.ranges = [[0, 0.5], [2, 6]]
a.video.dispatchEvent(new Event('progress'))
assert.equal(a.preparations(), 0, 'a future buffered range does not cover the playhead')
a.video.ranges = [[0, 5]]
a.video.paused = true
a.video.dispatchEvent(new Event('loadeddata'))
assert.equal(a.preparations(), 0)
a.video.paused = false
a.video.readyState = 1
a.video.dispatchEvent(new Event('progress'))
assert.equal(a.preparations(), 0)
a.video.readyState = 4
a.video.dispatchEvent(new Event('timeupdate'))
assert.equal(a.preparations(), 1)
assert.equal(a.policy.isDeferring(), false)
assert.equal(timers.size, 0)
assert.equal(a.video.listeners.size, 0)
a.policy.promote()
a.video.dispatchEvent(new Event('progress'))
assert.equal(a.preparations(), 1)

const b = fixture()
const timer = [...timers.values()][0]
timer.callback()
assert.equal(b.preparations(), 1, 'deadline promotes even without loadeddata')
assert.equal(timers.size, 0)
assert.equal(b.video.listeners.size, 0)
const c = fixture()
c.policy.promote()
assert.equal(c.preparations(), 1, 'manual interruption/profile change can promote immediately')
assert.equal(timers.size, 0)
const d = fixture()
d.policy.dispose()
d.policy.promote()
d.video.dispatchEvent(new Event('progress'))
assert.equal(d.preparations(), 0, 'unmount must not prepare media')
assert.equal(timers.size, 0)
assert.equal(d.video.listeners.size, 0)
const e = fixture(false)
assert.equal(e.policy.isDeferring(), false)
assert.equal(e.video.listeners.size, 0)
assert.equal(timers.size, 0)
const f = fixture()
f.video.dispatchEvent(new Event('error'))
assert.equal(f.preparations(), 1)
assert.equal(timers.size, 0)
const nearEnd = fixture()
nearEnd.video.currentTime = 4.5
nearEnd.video.ranges = [[0, 5.9]]
nearEnd.video.dispatchEvent(new Event('progress'))
assert.equal(nearEnd.preparations(), 0)
nearEnd.video.ranges = [[0, 6]]
nearEnd.video.dispatchEvent(new Event('progress'))
assert.equal(nearEnd.preparations(), 1, 'the fully buffered remainder needs no impossible 2.5-second lead')
const threshold = fixture()
threshold.video.ranges = [[0, 3.49]]
threshold.video.dispatchEvent(new Event('progress'))
assert.equal(threshold.preparations(), 0)
threshold.video.ranges = [[0, 3.5]]
threshold.video.dispatchEvent(new Event('progress'))
assert.equal(threshold.preparations(), 1, '2.5 seconds of playable lead releases Hero')
console.log('PASS: contiguous buffer lead, playback/readiness gate, bounded deadline without media events, immediate promotion, idempotence, disabled policy and cleanup.')
